        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="index.php">Start Bootstrap</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-4">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#!">About</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Shop</a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="?act=list&ma_danhmuc=0">Tất cả</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <?php
                                    foreach($dataDanhMuc as $value):
                                ?>
                                    <li><a class="dropdown-item" href="?act=list&ma_danhmuc=<?php echo $value['ma'];?>">
                                    <?php echo $value['ten'];?></a></li>
                                <?php
                                    endforeach;
                                ?>
                            </ul>
                        </li>
                    </ul>
                    
                    <form action="" method="get">
                        <input type="hidden" name="act" value="list">
                        <input type="text" name="keyword" style="border-radius: 5px; height: 35px;">
                        <input type="submit" value="Tìm kiếm" class="btn btn-outline-dark" style="margin-right: 20px;">
                    </form>
                    <!-- <form action="index.php?act=list" method="post">
                        <input type="text" name="keyword" style="border-radius: 5px; height: 35px;">
                        <input type="submit" name="search" value="Tìm kiếm" class="btn btn-outline-dark" style="margin-right: 20px;">
                    </form> -->
                    
                    <a class="btn btn-outline-dark" href="index.php?act=cart">
                        <i class="bi-cart-fill me-1"></i>
                        Cart
                        <span class="badge bg-dark text-white ms-1 rounded-pill">
                            <?php echo isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0; ?>
                        </span>
                    </a>
                </div>
            </div>
        </nav>
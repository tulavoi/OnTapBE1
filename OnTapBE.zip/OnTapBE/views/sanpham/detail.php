<div class="container" style="margin: 100px;">
    <div class="row">
        <?php foreach($data as $value):?>
        <div class="col-md-4">
            <img src="images/<?php echo $value['hinh'];?>" alt="Product Image" class="img-fluid">
        </div>

        <div class="col-md-8 d-flex flex-column justify-content-end">
            <h2><?php echo $value['ten'];?></h2>
            <p><?php echo $value['mota'];?></p>
            <p>Giá: <?php echo $value['gia'];?>$</p>

            <a href="?act=cart" class="btn btn-outline-dark" style="width: 20%;">Add to Cart</a>
        </div>
        <?php endforeach;?>
    </div>
</div>
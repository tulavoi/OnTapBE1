<?php
    //unset($_SESSION['cart']);

    // Xóa 1 sản phẩm
    if (isset($_GET['xoasp'])&&($_GET['xoasp']>=0)){
        array_splice($_SESSION['cart'],$_GET['xoasp'],1);
        header('Location: ?act=cart');
        exit;
    }

    // Xóa tất cả sản phẩm
    if (isset($_GET['xoaall'])&&($_GET['xoaall']==1)) unset($_SESSION['cart']);

    // Tính tổng giá sản phẩm
    function totalPrice(){
        $total = 0;
        if (isset($_SESSION['cart'])){
            for ($i=0; $i < sizeof($_SESSION['cart']); $i++) { 
                $total += $_SESSION['cart'][$i][2];
            }
        }
        return $total;
    }
?>
<div class="container mt-5">
    <h2>Your Cart</h2>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">STT</th>
                <th scope="col">Tên sản phẩm</th>
                <th scope="col">Hình</th>
                <th scope="col">Giá</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php 
                if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])):
                    for ($i=0; $i < sizeof($_SESSION['cart']); $i++):
            ?>
                    <tr>
                        <td><?php echo $i+1;?></td>
                        <td><?php echo $_SESSION['cart'][$i][0];?></td>
                        <td><img src="images/<?php echo $_SESSION['cart'][$i][1];?>" alt="" style="width:100px;"></td>
                        <td><?php echo $_SESSION['cart'][$i][2];?>$</td>
                        <td>
                            <a 
                                onclick="return confirm('Xác nhận xóa <?php echo $_SESSION['cart'][$i][0];?>?')"
                                href="?act=cart&xoasp=<?php echo $i?>" class="btn btn-danger btn-sm" name="xoasp">Xóa
                            </a>
                        </td>
                    </tr>
            <?php 
                    endfor;
                endif;
            ?>
        </tbody>
    </table>
    <a href="?act=cart&xoaall=1" class="btn btn-danger" name="xoaall">Xóa tất cả</a>

    <div class="text-right mt-5">
        <h4 class="mb-3">Tổng: <?php echo totalPrice();?>$</h4>
        <button class="btn btn-primary mb-5">Thanh toán</button>
    </div>
</div>
<?php
    $slSanPham = $db->getSoLuongSanPham();
    $slTrang = ceil($slSanPham/4);
    $ma_danhmuc = isset($_GET['ma_danhmuc']) ? $_GET['ma_danhmuc'] : 0;
    $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

    function createURL($page, $ma_danhmuc, $keyword){
        $url = "index.php?act=list&page=$page";
        if ($ma_danhmuc > 0) {
            $url .= "&ma_danhmuc=$ma_danhmuc";
        }
        if (!empty($keyword)) {
            $url .= "&keyword=$keyword";
        }
        return $url;
    }
?>
<nav arial-label="Page navigation">
    <ul class="pagination justify-content-center">
        <?php for($i = 1; $i <= $slTrang; $i++):?>
            <li class="page-item">
                <a href="<?php echo createURL($i, $ma_danhmuc, $keyword);?>" class="page-link"><?php echo $i;?></a>
            </li>
        <?php endfor;?>
    </ul>
</nav>
    
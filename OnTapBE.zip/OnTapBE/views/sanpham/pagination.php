<?php
    $slSanPham = $db->getSoLuongSanPham();
    $slTrang = ceil($slSanPham/4);
    $ma_danhmuc = isset($_GET['ma_danhmuc']) ? $_GET['ma_danhmuc'] : 0;
?>
<nav arial-label="Page navigation">
    <ul class="pagination justify-content-center">
        <?php for($i = 1; $i <= $slTrang; $i++):?>
            <li class="page-item"><a href="index.php?act=list&ma_danhmuc=<?php echo $ma_danhmuc;?>&page=<?php echo $i;?>" class="page-link"><?php echo $i;?></a></li>
        <?php endfor;?>
    </ul>
</nav>
    
<?php
    class SanPham{
        public $ma, $ten, $gia, $hinh, $maDanhMuc;
        public function __construct($ma, $ten, $gia, $hinh, $maDanhMuc){
            $this->ma = $ma;
            $this->ten = $ten;
            $this->gia = $gia;
            $this->hinh = $hinh;
            $this->maDanhMuc = $maDanhMuc;
        }
    }
?>
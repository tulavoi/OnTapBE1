<?php
    class DanhMuc{
        public $ma, $ten, $ghiChu;
        public function __construct($ma, $ten, $ghiChu){
            $this->ma = $ma;
            $this->ten = $ten;
            $this->ghiChu = $ghiChu;
        }
    }
?>
<?php 
    class Database{
        private $hostname = 'localhost';
        private $username = 'root';
        private $pass = 'vertrigo';
        private $dbname = 'qlsp';
        private $conn = null;
        private $result = null;

        public function connect(){
            $this->conn = new mysqli($this->hostname, $this->username, $this->pass, $this->dbname);
            if (!$this->conn){
                echo "Connect failed";
                exit();
            }else{
                mysqli_set_charset($this->conn, 'utf8');
            }
            return $this->conn;
        }

        // Thực thi câu lệnh truy vấn
        public function execute($sql){
            $this->result = $this->conn->query($sql);
            return $this->result;
        }

        // Đếm số lượng bản ghi
        public function num_rows(){
            if ($this->result){
                $num = mysqli_num_rows($this->result);
            }else{
                $num = 0;
            }
            return $num;
        }

        // Lấy dữ liệu
        public function getData(){
            if ($this->result){
                $data = mysqli_fetch_array($this->result);
            }else{
                $data = 0;
            }
            return $data;
        }

        // Lấy toàn bộ danh mục
        public function getAllDanhMuc(){
            $sql = "SELECT * FROM danhmuc";
            $this->execute($sql);
            $data = null;
            if ($this->num_rows()==0){
                $data = 0;
            }else{
                while($datas = $this->getData()){
                    $data[] = $datas;
                }
            }
            return $data;
        }

        // Phương thức lấy các sản phẩm theo danh mục
        public function getSanPhamTheoDanhMuc($ma_danhmuc, $page, $itemsPerPage){
            $offset = ($page - 1) * $itemsPerPage;
            $sql = "SELECT sanpham.* FROM sanpham
                    INNER JOIN danhmuc ON sanpham.madanhmuc = danhmuc.ma
                    WHERE sanpham.madanhmuc = '$ma_danhmuc'
                    LIMIT $itemsPerPage OFFSET $offset";
            $result = $this->execute($sql);
            if($result){
                $data = $result->fetch_all(MYSQLI_ASSOC);
                return $data;
            }else{
                return [];
            }
        }

        // Lấy toàn bộ sản phẩm
        public function getAllSanPham($page, $itemsPerPage){
            $offset = ($page - 1) * $itemsPerPage;
            $sql = "SELECT * FROM sanpham LIMIT $itemsPerPage OFFSET $offset";
            $this->execute($sql);
            $data = null;
            if ($this->num_rows()==0){
                $data = 0;
            }else{
                while($datas = $this->getData()){
                    $data[] = $datas;
                }
            }
            return $data;
        }

        // Lấy số lượng sản phẩm
        public function getSoLuongSanPham(){
            $sql = "SELECT COUNT(*) AS total FROM sanpham";
            $this->execute($sql);

            $result = $this->conn->query($sql);
            if ($result === false) {
                return false;
            }
            $row = $result->fetch_assoc();
            return $row['total'];
        }

        // Lấy sản phẩm theo mã
        public function getSanPhamTheoMa($ma_sanpham){
            $sql = "SELECT * FROM sanpham WHERE ma = '$ma_sanpham'";
            $this->execute($sql);
            $data = null;
            if ($this->num_rows()==0){
                $data = 0;
            }else{
                while($datas = $this->getData()){
                    $data[] = $datas;
                }
            }
            return $data;
        }

        // Tìm sản phẩm bằng từ khóa
        public function timSanPham($keyword, $page, $itemsPerPage){
            $offset = ($page - 1) * $itemsPerPage;
            $keyword = '%'.$keyword.'%';
            $sql = "SELECT * FROM sanpham WHERE ten LIKE '$keyword' OR mota LIKE '$keyword' LIMIT $itemsPerPage OFFSET $offset";
            $this->execute($sql);
            $data = null;
            if ($this->num_rows()==0){
                $data = 0;
            }else{
                while($datas = $this->getData()){
                    $data[] = $datas;
                }
            }
            return $data;
        }
    }
?>
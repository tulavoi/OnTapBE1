<?php
    if (isset($_GET['act'])){
        $act = $_GET['act'];
    }else{
        $act = '';
    }

    $dataDanhMuc = $db->getAllDanhMuc();

    session_start();
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    if ($_SERVER['REQUEST_METHOD'] === 'POST'){
        if (isset($_POST['addtocart']) && $_POST['addtocart']){
            $ten = $_POST['ten'];
            $gia = $_POST['gia'];
            $hinh = $_POST['hinh'];
            $sanpham = [$ten, $hinh, $gia];
            $_SESSION['cart'][] = $sanpham;

            $_SESSION['success_msg'] = 'Thêm vào giỏ hàng thành công!';
        }
    }
    $successMsg = isset($_SESSION['success_msg']) ? $_SESSION['success_msg'] : '';
    unset($_SESSION['success_msg']);
    require_once 'views/navbar.php';

    switch ($act) {
        case 'add':
            require_once 'views/danhmuc/add.php';
            break;

        case 'edit':
            require_once 'views/danhmuc/edit.php';
            break;
        
        case 'delete':
            require_once 'views/danhmuc/delete.php';
            break;

        case 'detail':
            $ma_sanpham = isset($_GET['id']) ? $_GET['id'] : 0;
            $data = $db->getSanPhamTheoMa($ma_sanpham);
            require_once 'views/sanpham/detail.php';
            break;

        case 'cart':
            require_once 'views/sanpham/cart.php';
            break;

        case 'list':
            $page = isset($_GET['page']) ? $_GET['page'] : 1;
            $ma_danhmuc = isset($_GET['ma_danhmuc']) ? $_GET['ma_danhmuc'] : 0;
            $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';

            if ($ma_danhmuc > 0){
                $data = $db->timSanPham($ma_danhmuc, $keyword, $page, 4);
            }
            else if ($keyword != ''){
                $data = $db->timSanPham($ma_danhmuc, $keyword, $page, 4);
            }else{
                $data = $db->getAllSanPham($page, 4);
            }

            require_once 'views/danhmuc/header.php';
            require_once 'views/sanpham/list.php';
            break;

        default:
            $page = isset($_GET['page']) ? $_GET['page'] : 1;
            $data = $db->getAllSanPham($page, 4);
            require_once 'views/danhmuc/header.php';
            require_once 'views/sanpham/list.php';
            break;
    }
    require_once 'views/footer.php';
?>
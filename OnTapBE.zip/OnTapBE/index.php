<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Shop Homepage - Start Bootstrap Template</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="public/css/styles.css" rel="stylesheet" />
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php
            include 'models/DBConfig.php';
            $db = new Database();
            $db->connect();

            if (isset($_GET['controller'])){
                $controller = $_GET['controller'];
            }else{
                $controller = '';
            }

            switch ($controller) {
                case 'danhmuc':
                    require_once 'controllers/danhmuc/index.php';
                    break;
                
                case 'sanpham':
                    require_once 'controllers/sanpham/index.php';
                    break;

                default:
                    require_once 'controllers/danhmuc/index.php';
                    break;
            }
        ?>
    </body>
</html>
